import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Stethoscope, Plus, Trash2, ShieldAlert, Star, 
  Clock, DollarSign, Building, Award, UserCheck, ChevronDown, CheckCircle, PlusCircle, RefreshCw
} from 'lucide-react';
import { Doctor } from '../types.js';

interface ManageDoctorsProps {
  doctors: Doctor[];
  loading: boolean;
  onAddDoctor: (doctorData: Omit<Doctor, 'id' | 'rating'>) => Promise<boolean>;
  onRemoveDoctor: (id: string) => Promise<boolean>;
}

export default function ManageDoctors({ doctors, loading, onAddDoctor, onRemoveDoctor }: ManageDoctorsProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [formName, setFormName] = useState('');
  const [formSpecialty, setFormSpecialty] = useState('Cardiology');
  const [formExperience, setFormExperience] = useState('');
  const [formHospital, setFormHospital] = useState('');
  const [formFee, setFormFee] = useState('100');
  const [formAvailability, setFormAvailability] = useState('');
  const [formBio, setFormBio] = useState('');
  
  const [submitState, setSubmitState] = useState<'idle' | 'saving' | 'success' | 'error'>('idle');

  const specialties = [
    'Cardiology',
    'Dermatology',
    'Neurology',
    'Pediatrics',
    'Endocrinology',
    'Orthopedics',
    'Gastroenterology',
    'Pulmonology',
    'Psychiatry',
    'Ophthalmology',
    'General Medicine'
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formSpecialty) return;

    setSubmitState('saving');
    const success = await onAddDoctor({
      name: formName.startsWith('Dr. ') ? formName : `Dr. ${formName}`,
      specialty: formSpecialty,
      experience: formExperience || '5 years',
      hospital: formHospital || 'General Medical Clinic',
      consultation_fee: Number(formFee) || 100,
      availability: formAvailability || 'Mon-Fri 09:00 - 17:00',
      bio: formBio || 'Expert medical consultant dedicated to comprehensive wellness.'
    });

    if (success) {
      setSubmitState('success');
      setTimeout(() => {
        setSubmitState('idle');
        setShowAddForm(false);
        // Reset form fields
        setFormName('');
        setFormExperience('');
        setFormHospital('');
        setFormFee('100');
        setFormAvailability('');
        setFormBio('');
      }, 1500);
    } else {
      setSubmitState('error');
    }
  };

  return (
    <div className="space-y-6 font-sans">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
        <div>
          <h2 className="text-lg font-extrabold text-gray-900 tracking-tight flex items-center gap-2">
            <Stethoscope className="w-5 h-5 text-blue-600" />
            Specialists & Doctors Registry
          </h2>
          <p className="text-gray-500 text-xs">Register, audit, and coordinate the active medical team of medical specialists.</p>
        </div>
        
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-md shadow-blue-200 hover:shadow-blue-300 transition duration-150 flex items-center justify-center gap-2 cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          {showAddForm ? 'Cancel Registration' : 'Register New Doctor'}
        </button>
      </div>

      {/* Add Doctor Registry Form */}
      <AnimatePresence>
        {showAddForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <form onSubmit={handleSubmit} className="bg-white border border-blue-100 rounded-2xl p-6 shadow-sm space-y-4">
              <h3 className="text-xs font-extrabold text-blue-900 uppercase tracking-widest border-b border-blue-50 pb-2 flex items-center gap-2">
                <PlusCircle className="w-4 h-4 text-blue-500" />
                Specialist Enlistment Form
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                {/* Name */}
                <div className="space-y-1">
                  <label className="text-[10px] text-gray-400 font-extrabold uppercase tracking-wider block">Full Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Clara Thorne"
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full text-xs font-semibold px-3 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
                  />
                </div>

                {/* Specialty */}
                <div className="space-y-1">
                  <label className="text-[10px] text-gray-400 font-extrabold uppercase tracking-wider block">Clinical Specialty</label>
                  <select
                    value={formSpecialty}
                    onChange={(e) => setFormSpecialty(e.target.value)}
                    className="w-full text-xs font-semibold px-3 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none bg-white cursor-pointer"
                  >
                    {specialties.map(spec => (
                      <option key={spec} value={spec}>{spec}</option>
                    ))}
                  </select>
                </div>

                {/* Experience */}
                <div className="space-y-1">
                  <label className="text-[10px] text-gray-400 font-extrabold uppercase tracking-wider block">Years of Experience</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 12 years"
                    value={formExperience}
                    onChange={(e) => setFormExperience(e.target.value)}
                    className="w-full text-xs font-semibold px-3 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
                  />
                </div>

                {/* Hospital */}
                <div className="space-y-1">
                  <label className="text-[10px] text-gray-400 font-extrabold uppercase tracking-wider block">Affiliated Hospital</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Metro Heart & Vascular Center"
                    value={formHospital}
                    onChange={(e) => setFormHospital(e.target.value)}
                    className="w-full text-xs font-semibold px-3 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
                  />
                </div>

                {/* Fee */}
                <div className="space-y-1">
                  <label className="text-[10px] text-gray-400 font-extrabold uppercase tracking-wider block">Consultation Fee ($)</label>
                  <input
                    type="number"
                    required
                    min="1"
                    placeholder="120"
                    value={formFee}
                    onChange={(e) => setFormFee(e.target.value)}
                    className="w-full text-xs font-semibold px-3 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
                  />
                </div>

                {/* Availability */}
                <div className="space-y-1">
                  <label className="text-[10px] text-gray-400 font-extrabold uppercase tracking-wider block">Weekly Availability</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Mon, Wed, Fri 09:00 - 13:00"
                    value={formAvailability}
                    onChange={(e) => setFormAvailability(e.target.value)}
                    className="w-full text-xs font-semibold px-3 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none"
                  />
                </div>

              </div>

              {/* Bio */}
              <div className="space-y-1">
                <label className="text-[10px] text-gray-400 font-extrabold uppercase tracking-wider block">Professional Bio & Focus Area</label>
                <textarea
                  required
                  rows={2}
                  placeholder="Describe specialty focus, clinical background, research areas..."
                  value={formBio}
                  onChange={(e) => setFormBio(e.target.value)}
                  className="w-full text-xs font-semibold px-3 py-2.5 rounded-xl border border-gray-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none resize-none"
                />
              </div>

              {/* Form Actions */}
              <div className="flex justify-end gap-3 pt-2">
                {submitState === 'saving' && (
                  <span className="text-xs text-blue-600 font-bold self-center animate-pulse">Enlisting practitioner...</span>
                )}
                {submitState === 'success' && (
                  <span className="text-xs text-emerald-600 font-bold self-center">✓ Enlisted successfully!</span>
                )}
                {submitState === 'error' && (
                  <span className="text-xs text-red-600 font-bold self-center">Error listing doctor. Try again.</span>
                )}

                <button
                  type="submit"
                  disabled={submitState === 'saving'}
                  className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-bold px-5 py-2.5 rounded-xl transition cursor-pointer"
                >
                  Save to Registry
                </button>
              </div>

            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Grid of registered specialists */}
      {loading ? (
        <div className="flex flex-col items-center justify-center p-12 bg-white rounded-3xl border border-gray-100">
          <RefreshCw className="w-8 h-8 text-blue-600 animate-spin mb-2" />
          <p className="text-gray-500 text-xs font-bold">Synchronizing medical registry...</p>
        </div>
      ) : doctors.length === 0 ? (
        <div className="flex flex-col items-center justify-center p-12 bg-white rounded-3xl border border-gray-100 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center">
            <ShieldAlert className="w-6 h-6 text-slate-400" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-gray-900">No registered specialists</h4>
            <p className="text-gray-500 text-xs">Add your primary clinical specialists to open consultation portals.</p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {doctors.map((doctor) => (
            <motion.div
              key={doctor.id}
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white border border-gray-150 rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition duration-200 flex flex-col justify-between"
            >
              <div className="p-5 space-y-4">
                
                {/* Card Title & Badges */}
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-extrabold text-gray-900 text-sm tracking-tight">{doctor.name}</h4>
                    <span className="inline-block mt-1 text-[9px] font-extrabold uppercase tracking-widest text-blue-600 bg-blue-50 px-2.5 py-1 rounded-md">
                      {doctor.specialty}
                    </span>
                  </div>
                  
                  {/* Rating Badge */}
                  <div className="flex items-center gap-1 bg-amber-50 px-2 py-1 rounded-lg">
                    <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                    <span className="text-[10px] text-amber-850 font-bold">{doctor.rating?.toFixed(1) || '5.0'}</span>
                  </div>
                </div>

                {/* Professional details */}
                <div className="space-y-2 text-xs font-semibold text-gray-600">
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4 text-slate-400 shrink-0" />
                    <span>{doctor.experience} Experience</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Building className="w-4 h-4 text-slate-400 shrink-0" />
                    <span className="truncate">{doctor.hospital}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-slate-400 shrink-0" />
                    <span className="text-[11px] text-gray-500 font-medium">{doctor.availability}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span className="font-extrabold text-emerald-700">${doctor.consultation_fee} consultation fee</span>
                  </div>
                </div>

                {/* Bio text block */}
                <div className="bg-slate-50/50 p-3 rounded-xl border border-slate-100">
                  <p className="text-[10px] text-gray-500 leading-relaxed italic">
                    "{doctor.bio || 'Comprehensive medical services.'}"
                  </p>
                </div>

              </div>

              {/* Card Action footer */}
              <div className="border-t border-slate-100 px-5 py-3.5 bg-slate-50 flex items-center justify-between">
                <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">ID: {doctor.id}</span>
                
                <button
                  onClick={() => {
                    const confirmRemove = window.confirm(`Are you sure you want to retire ${doctor.name} from the medical directory?`);
                    if (confirmRemove) {
                      onRemoveDoctor(doctor.id);
                    }
                  }}
                  className="p-2 hover:bg-red-50 text-slate-400 hover:text-red-600 rounded-lg transition duration-150 cursor-pointer"
                  title="Remove Doctor"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

            </motion.div>
          ))}
        </div>
      )}

    </div>
  );
}
