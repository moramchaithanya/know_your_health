import React, { useState, useEffect } from 'react';
import { 
  initGoogleAuth, googleSignIn, googleLogout, 
  getCachedAccessToken, getGoogleUser 
} from '../lib/googleAuth.js';
import { triggerGoogleSheetsSync } from '../lib/sheetsService.js';
import { 
  FileSpreadsheet, LogIn, LogOut, CheckCircle2, 
  AlertCircle, RefreshCw, ExternalLink, ShieldCheck 
} from 'lucide-react';

export default function GoogleSheetsSync() {
  const [needsAuth, setNeedsAuth] = useState(true);
  const [googleEmail, setGoogleEmail] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState<{ success: boolean; message: string; sheetUrl?: string } | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);

  useEffect(() => {
    const unsubscribe = initGoogleAuth(
      (user, token) => {
        setNeedsAuth(false);
        setGoogleEmail(user.email);
        setIsInitializing(false);
      },
      () => {
        setNeedsAuth(true);
        setGoogleEmail(null);
        setIsInitializing(false);
      }
    );
    return () => unsubscribe();
  }, []);

  const handleConnect = async () => {
    try {
      const res = await googleSignIn();
      if (res) {
        setNeedsAuth(false);
        setGoogleEmail(res.user.email);
        setSyncResult(null);
      }
    } catch (err: any) {
      console.error("Failed to authenticate with Google:", err);
      setSyncResult({ success: false, message: `Authentication failed: ${err.message}` });
    }
  };

  const handleDisconnect = async () => {
    try {
      await googleLogout();
      setNeedsAuth(true);
      setGoogleEmail(null);
      setSyncResult(null);
    } catch (err: any) {
      console.error("Failed to disconnect:", err);
    }
  };

  const handleSync = async () => {
    setIsSyncing(true);
    setSyncResult(null);
    try {
      const token = getCachedAccessToken();
      if (!token) {
        setNeedsAuth(true);
        throw new Error("Google access token not found. Please connect again.");
      }

      const res = await triggerGoogleSheetsSync(token);
      setSyncResult(res);
    } catch (err: any) {
      console.error("Google Sheets Sync failed:", err);
      setSyncResult({
        success: false,
        message: `Sync failed: ${err.message}`
      });
    } finally {
      setIsSyncing(false);
    }
  };

  if (isInitializing) {
    return (
      <div className="flex items-center gap-2 text-xs text-gray-500 py-3">
        <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-600" />
        Initializing Google integration...
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-emerald-50/60 to-teal-50/40 border border-emerald-100 rounded-2xl p-5 space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-1.5">
          <h3 className="text-sm font-bold text-emerald-950 flex items-center gap-1.5 uppercase tracking-wide">
            <FileSpreadsheet className="w-4.5 h-4.5 text-emerald-600 shrink-0" />
            Google Sheets Sync Engine
          </h3>
          <p className="text-xs text-emerald-800 leading-relaxed">
            Synchronize diagnostic registry, patient profiles, and AI-powered disease predictions directly to your secure Google Sheets spreadsheet.
          </p>
        </div>
        {needsAuth ? (
          <button
            id="btn-connect-google"
            onClick={handleConnect}
            className="shrink-0 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3.5 py-2 rounded-xl shadow-sm flex items-center gap-1.5 transition"
          >
            <LogIn className="w-3.5 h-3.5" />
            Connect Google
          </button>
        ) : (
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-1 rounded-lg flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              {googleEmail}
            </span>
            <button
              id="btn-disconnect-google"
              onClick={handleDisconnect}
              title="Disconnect Google account"
              className="p-2 hover:bg-red-50 text-red-500 hover:text-red-700 rounded-lg transition"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {!needsAuth && (
        <div className="pt-2 border-t border-emerald-100/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="text-[11px] text-emerald-900 font-medium">
            Ready to export all patient registers & ensemble AI models.
          </div>
          <button
            id="btn-sync-sheets"
            onClick={handleSync}
            disabled={isSyncing}
            className="bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-md flex items-center justify-center gap-2 transition"
          >
            {isSyncing ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                Syncing database...
              </>
            ) : (
              <>
                <FileSpreadsheet className="w-3.5 h-3.5" />
                Sync to Google Sheets
              </>
            )}
          </button>
        </div>
      )}

      {syncResult && (
        <div className={`p-4 rounded-xl border text-xs flex items-start gap-2.5 transition animate-fade-in ${
          syncResult.success 
            ? 'bg-emerald-50 border-emerald-100 text-emerald-900' 
            : 'bg-red-50 border-red-100 text-red-950'
        }`}>
          {syncResult.success ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          ) : (
            <AlertCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
          )}
          <div className="space-y-1.5 flex-1">
            <p className="font-medium">{syncResult.message}</p>
            {syncResult.sheetUrl && (
              <a
                id="link-open-spreadsheet"
                href={syncResult.sheetUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-teal-700 hover:text-teal-950 font-bold underline transition"
              >
                Open Google Spreadsheet
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
